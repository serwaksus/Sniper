import os
import json
import logging
import re
from dataclasses import dataclass
from typing import Optional, Dict, Any, List

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

try:
    from curl_cffi import requests as curl_requests
except ImportError:
    raise ImportError("curl_cffi not installed. Run: pip install curl_cffi")

try:
    import pandas as pd
except ImportError:
    pd = None

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class MetaculusQuestion:
    id: int
    title: str
    resolution: Optional[str] = None
    probability: Optional[float] = None
    community_prediction: Optional[float] = None
    created_at: Optional[str] = None
    resolve_date: Optional[str] = None
    url: Optional[str] = None
    description: Optional[str] = None
    categories: Optional[List[str]] = None
    num_predictions: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "resolution": self.resolution,
            "probability": self.probability,
            "community_prediction": self.community_prediction,
            "created_at": self.created_at,
            "resolve_date": self.resolve_date,
            "url": self.url,
            "description": self.description,
            "categories": self.categories,
            "num_predictions": self.num_predictions
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)


class MetaculusParser:
    BASE_URL = "https://www.metaculus.com"
    API_BASE = "https://www.metaculus.com/api2"

    CHROME_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"

    def __init__(self, token: Optional[str] = None):
        self.token = token or os.getenv("METACULUS_TOKEN")
        self._session = None

    @property
    def session(self):
        if self._session is None:
            self._session = curl_requests.Session(impersonate="chrome")
            self._setup_session()
        return self._session

    def _setup_session(self):
        self._session.headers.update({
            "User-Agent": self.CHROME_UA,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate, br",
            "Sec-Ch-Ua": '"Not_A Brand";v="99", "Google Chrome";v="121", "Chromium";v="121"',
            "Sec-Ch-Ua-Mobile": "?0",
            "Sec-Ch-Ua-Platform": '"Windows"',
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
            "Upgrade-Insecure-Requests": "1",
        })

    def _get_api_headers(self) -> Dict[str, str]:
        headers = {
            "User-Agent": self.CHROME_UA,
            "Accept": "application/json",
            "Accept-Language": "en-US,en;q=0.9",
            "Content-Type": "application/json",
            "Referer": f"{self.BASE_URL}/",
            "Origin": self.BASE_URL,
        }
        if self.token:
            headers["Authorization"] = f"Token {self.token}"
        return headers

    def _extract_from_html(self, html: str, question_id: int) -> Optional[Dict]:
        post_pattern = '\\"post\\":{\\"id\\":' + str(question_id)
        idx = html.find(post_pattern)
        if idx < 0:
            return None

        search_start = max(0, idx - 500)
        brace_idx = html.rfind('{', search_start, idx)
        if brace_idx < 0:
            return None

        depth = 0
        for i in range(brace_idx, len(html)):
            c = html[i]
            if c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
                if depth == 0:
                    break

        json_str = html[brace_idx:i+1]
        try:
            json_str_decoded = json_str.encode('utf-8').decode('unicode_escape')
            return json.loads(json_str_decoded)
        except Exception:
            return None

    def _extract_forecast_values(self, html: str, question_id: int) -> Optional[float]:
        pattern = r'"forecast_values\\":\[(0\.\d+),'
        match = re.search(pattern, html)
        if match:
            return float(match.group(1))
        return None

    def get_question(self, question_id: int) -> Optional[MetaculusQuestion]:
        try:
            page_url = f"{self.BASE_URL}/questions/{question_id}/"
            resp = self.session.get(page_url, headers=self._get_api_headers(), timeout=30)

            if resp.status_code != 200:
                logger.error(f"Page request failed with status {resp.status_code}")
                return None

            html = resp.text

            data = self._extract_from_html(html, question_id)
            probability = self._extract_forecast_values(html, question_id)

            if not data:
                return None

            return self._parse_question_data(data, question_id, probability)

        except Exception as e:
            logger.error(f"Failed to fetch question {question_id}: {e}")
            return None

    def _parse_question_data(self, data: Dict, question_id: int, probability: Optional[float] = None) -> Optional[MetaculusQuestion]:
        try:
            post = data.get('post', {})
            question = post.get('question', {})

            if probability is None:
                metaculus_pred = post.get('metaculus_prediction', {})
                latest = metaculus_pred.get('latest', {})
                if latest:
                    forecast_values = latest.get('forecast_values', [])
                    if forecast_values and len(forecast_values) >= 1:
                        probability = forecast_values[0]

            cats = post.get('categories', [])
            if not cats and 'projects' in post:
                projects = post.get('projects', {})
                if 'category' in projects:
                    cats = [c.get('name') for c in projects['category'] if isinstance(c, dict)]

            resolve_date = question.get('scheduled_resolve_time') or post.get('scheduled_resolve_time')
            if not resolve_date:
                resolve_date = post.get('scheduled_resolve_time')

            return MetaculusQuestion(
                id=question_id,
                title=post.get('title', ''),
                resolution=post.get('resolution'),
                probability=probability,
                community_prediction=probability,
                created_at=post.get('created_at'),
                resolve_date=resolve_date,
                url=f"{self.BASE_URL}/questions/{question_id}",
                description=question.get('description', post.get('description', '')),
                categories=cats if isinstance(cats, list) else [],
                num_predictions=post.get('forecasts_count') or post.get('nr_forecasters')
            )
        except Exception as e:
            logger.error(f"Failed to parse question data: {e}")
            return None

    def get_question_to_df(self, question_id: int) -> Optional[pd.DataFrame]:
        q = self.get_question(question_id)
        return pd.DataFrame([q.to_dict()]) if q else None

    def get_questions_list(self, search: Optional[str] = None,
                          categories: Optional[List[str]] = None,
                          limit: int = 20) -> List[MetaculusQuestion]:
        try:
            params = {"limit": limit}
            if search:
                params["search"] = search

            resp = self.session.get(
                f"{self.API_BASE}/questions/",
                params=params,
                headers=self._get_api_headers(),
                timeout=30
            )

            if resp.status_code == 403:
                logger.warning("API returned 403 for questions list")
                return []

            resp.raise_for_status()
            data = resp.json()
            results = data.get("results", []) if isinstance(data, dict) else []

            questions = []
            for item in results[:limit]:
                try:
                    q_id = item.get("id", 0)
                    cp = item.get("community_prediction", {})
                    prob = cp.get("value") if isinstance(cp, dict) else None

                    resolve_date = item.get("resolve_date") or item.get("scheduled_resolve_time")

                    questions.append(MetaculusQuestion(
                        id=q_id,
                        title=item.get("title", ""),
                        resolution=item.get("resolution"),
                        probability=prob,
                        community_prediction=prob,
                        created_at=item.get("created_at"),
                        resolve_date=resolve_date,
                        url=f"{self.BASE_URL}/questions/{q_id}",
                        categories=[c.get("name") if isinstance(c, dict) else str(c) for c in item.get("categories", [])],
                        num_predictions=item.get("num_predictions")
                    ))
                except Exception:
                    continue

            return questions

        except Exception as e:
            logger.error(f"Failed to fetch questions: {e}")
            return []

    def get_questions_to_df(self, **kwargs) -> Optional[pd.DataFrame]:
        questions = self.get_questions_list(**kwargs)
        return pd.DataFrame([q.to_dict() for q in questions]) if questions else None

    def close(self):
        if self._session:
            self._session.close()
            self._session = None

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass


if __name__ == "__main__":
    print("=" * 60)
    print("Testing Metaculus Parser (curl_cffi + HTML parsing)")
    print("=" * 60)

    parser = MetaculusParser()

    question_id = 578
    print(f"\nFetching question ID: {question_id}")

    question = parser.get_question(question_id)

    if question:
        print(f"\nTitle: {question.title}")
        print(f"URL: {question.url}")
        print(f"Probability: {question.probability}")
        print(f"Community Prediction: {question.community_prediction}")
        print(f"Resolution: {question.resolution}")
        print(f"Resolve Date: {question.resolve_date}")
        print(f"Categories: {question.categories}")
        print(f"Num Predictions: {question.num_predictions}")
        print("\nJSON output:")
        print(question.to_json())
    else:
        print("Failed to fetch question")

    print("\n" + "=" * 60)
    print("Testing question list (search 'AI')")
    print("=" * 60)

    questions = parser.get_questions_list(search="AI", limit=5)
    print(f"Found {len(questions)} questions")
    for q in questions:
        title_short = q.title[:50] + "..." if len(q.title) > 50 else q.title
        print(f"  - [{q.id}] {title_short} | prob={q.probability}")

    df = parser.get_questions_to_df(search="AI", limit=5)
    if df is not None and not df.empty:
        print("\nDataFrame sample:")
        print(df[["id", "title", "probability"]].to_string())
    else:
        print("\nNo questions found or DataFrame empty")

    parser.close()
    print("\nTest complete.")